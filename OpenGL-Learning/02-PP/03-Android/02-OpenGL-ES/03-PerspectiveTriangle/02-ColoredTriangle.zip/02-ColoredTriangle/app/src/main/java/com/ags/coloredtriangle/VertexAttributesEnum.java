package com.ags.coloredtriangle;

public class VertexAttributesEnum {
    public static final int AGS_ATTRIBUTE_POSITION = 0;
    public static final int AGS_ATTRIBUTE_COLOR = 1;
    public static final int AGS_ATTRIBUTE_NORMAL = 2;
    public static final int AGS_ATTRIBUTE_TEXTURE0 = 3;
}